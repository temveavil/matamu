Set WshShell = CreateObject("WScript.Shell")
WshShell.Run "cmd /c php -S localhost:8000", 0, False